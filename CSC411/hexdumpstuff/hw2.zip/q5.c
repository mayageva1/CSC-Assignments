#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>


uint8_t swap(uint8_t x) {
    // TODO
}


int main(int argc, char* argv[]) {
    uint8_t x;
    scanf("%" SCNu8, &x);
    printf("%" PRIu8 "\n", swap(x));
}
