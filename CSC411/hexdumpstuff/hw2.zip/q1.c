#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>


uint8_t get_upper_byte(uint16_t x) {
    // TODO
}


int main(int argc, char* argv[]) {
    uint16_t x;
    scanf("%" SCNu16, &x);
    printf("%" PRIu8 "\n", get_upper_byte(x));
}
