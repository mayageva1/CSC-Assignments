#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>


uint8_t is_power_of_two(uint64_t x) {
    // TODO
}


int main(int argc, char* argv[]) {
    uint64_t x;
    scanf("%" SCNu64, &x);
    printf("%" PRIu8 "\n", is_power_of_two(x));
}
